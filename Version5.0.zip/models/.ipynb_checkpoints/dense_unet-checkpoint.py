import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models.densenet import _DenseBlock, _Transition
from torch.utils.checkpoint import checkpoint

class DenseUNet(nn.Module):
    def __init__(self, n_classes, in_channels=3, growth_rate=32, block_config=(6, 12, 24, 16),
                 num_init_features=64, bn_size=4, drop_rate=0, use_checkpointing=False):
        super(DenseUNet, self).__init__()
        self.use_checkpointing = use_checkpointing

        # First convolution
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, num_init_features, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(num_init_features),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        )

        # Encoder (downsampling)
        num_features = num_init_features
        self.encoder_blocks = nn.ModuleList()
        for i, num_layers in enumerate(block_config):
            block = _DenseBlock(num_layers=num_layers, num_input_features=num_features,
                                bn_size=bn_size, growth_rate=growth_rate, drop_rate=drop_rate)
            self.encoder_blocks.append(block)
            num_features = num_features + num_layers * growth_rate
            if i != len(block_config) - 1:
                trans = _Transition(num_input_features=num_features, num_output_features=num_features // 2)
                self.encoder_blocks.append(trans)
                num_features = num_features // 2

        # Decoder (upsampling)
        self.decoder_blocks = nn.ModuleList()
        for i in reversed(range(len(block_config) - 1)):
            num_input_features = num_features + block_config[i] * growth_rate
            block = _DenseBlock(num_layers=block_config[i], num_input_features=num_input_features,
                                bn_size=bn_size, growth_rate=growth_rate, drop_rate=drop_rate)
            self.decoder_blocks.append(block)
            num_features += block_config[i] * growth_rate
            
            if i > 0:
                trans = nn.ConvTranspose2d(num_features, num_features // 2, kernel_size=2, stride=2)
                self.decoder_blocks.append(trans)
                num_features = num_features // 2

        # Final convolution
        self.final_conv = nn.Conv2d(num_features, n_classes, kernel_size=1)

    def forward(self, x):
        print(f"Input shape: {x.shape}")
        features = [x]
        
        # Initial convolution
        x = self.features(x)
        print(f"After initial features: {x.shape}")
        features.append(x)

        # Encoder
        for i, block in enumerate(self.encoder_blocks):
            if self.use_checkpointing and isinstance(block, _DenseBlock):
                x = checkpoint(block, x)
            else:
                x = block(x)
            print(f"After encoder block {i}: {x.shape}")
            if isinstance(block, _DenseBlock):
                features.append(x)

        # Decoder
        for i, block in enumerate(self.decoder_blocks):
            if isinstance(block, nn.ConvTranspose2d):
                x = block(x)
                x = torch.cat([x, features[-i-2]], dim=1)
                print(f"After decoder transpose {i}: {x.shape}")
            else:
                if self.use_checkpointing:
                    x = checkpoint(block, x)
                else:
                    x = block(x)
                print(f"After decoder block {i}: {x.shape}")

        x = self.final_conv(x)
        print(f"Final output: {x.shape}")
        return x

def init_weights(m):
    if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
        nn.init.kaiming_normal_(m.weight)
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.constant_(m.weight, 1)
        nn.init.constant_(m.bias, 0)